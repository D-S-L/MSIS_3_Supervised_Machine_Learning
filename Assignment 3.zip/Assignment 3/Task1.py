class Task1:
    # please feel free to create new python files, adding functions and attributes to do training, validation, testing

    def __init__(self):
        print("================Task 1================")
        return

    def model_1_run(self):
        print("Model 1:")
        # Train the model 1 with your best hyper parameters (if have) and features on training data.


        # Evaluate learned model on testing data, and print the results.
        print("Mean squared error\t" + str(0.0))
        return

    def model_2_run(self):
        print("--------------------\nModel 2:")
        # Train the model 2 with your best hyper parameters (if have) and features on training data.


        # Evaluate learned model on testing data, and print the results.
        print("Mean squared error\t" + str(0.0))
        return
